Harrison Giltner- set up the pages and fixed the text in Dicelopdeia
I couldn't get more as apparently I got my access denied